
<?php
session_start();

// Check if ID is provided
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Get existing products from session
    $products = $_SESSION['Products'];
    
    // Find and remove the product
    foreach($products as $key => $product) {
        if($product['ID'] == $id) {
            unset($products[$key]);
            break;
        }
    }
    
    // Re-index the array to avoid empty spots
    $products = array_values($products);
    
    // Save updated products back to session
    $_SESSION['Products'] = $products;
    
    // Redirect back to viewProduct.php
    header("Location: viewProduct.php");
    exit();
} else {
    // If no ID provided, redirect back
    header("Location: viewProduct.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
</head>
<body>
    <a href="../view/viewProduct.php">GO BACK</a><br>
    <form action="../controller/updatePerform.php" method="POST">
        ID: <input type="text" name="id" value="<?php echo isset($product['ID']) ? $product['ID'] : ''; ?>" readonly><br>
        Name: <input type="text" name="name" value="<?php echo isset($product['Name']) ? $product['Name'] : ''; ?>"><br>
        Price: <input type="text" name="price" value="<?php echo isset($product['Price']) ? $product['Price'] : ''; ?>"><br>
        Quantity: <input type="text" name="quantity" value="<?php echo isset($product['Quantity']) ? $product['Quantity'] : ''; ?>"><br>
        <input type="submit" name="submit" value="DELETE">
    </form>
</body>
</html>